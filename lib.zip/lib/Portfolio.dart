//import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Portfolio extends StatelessWidget {
  const Portfolio({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("This is Portfolio"),
      ),
    );
  }
}
